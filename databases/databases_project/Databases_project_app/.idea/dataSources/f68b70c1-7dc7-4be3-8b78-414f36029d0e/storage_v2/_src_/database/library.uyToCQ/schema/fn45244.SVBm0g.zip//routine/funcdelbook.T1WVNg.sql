create function funcdelbook() returns trigger
    language plpgsql
as
$$
BEGIN
	DELETE FROM Inventory WHERE ISBN = OLD.ISBN;
END
$$;

alter function funcdelbook() owner to postgres;

