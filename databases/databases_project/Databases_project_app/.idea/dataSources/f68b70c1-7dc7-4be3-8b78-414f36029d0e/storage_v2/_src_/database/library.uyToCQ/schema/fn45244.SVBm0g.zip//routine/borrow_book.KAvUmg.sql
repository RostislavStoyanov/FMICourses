create function borrow_book(rid integer, bisbn character, depnumber integer) returns character varying
    language plpgsql
as
$$
DECLARE
	currDate DATE;
	returnDate DATE;
	sysNo VARCHAR(255);
BEGIN
	currDate := CURRENT_DATE;
	returnDate := currDate + interval '20 days';

	IF NOT EXISTS (SELECT 1 FROM Reader WHERE ReaderID = rID)
	THEN 
		RAISE unique_violation USING MESSAGE = 'No such reader';
		RETURN NULL;
	END IF;
	
	IF (SELECT 1 FROM DEP_CONTAINS_ISBN(bISBN,depNumber))
	THEN
		sysNo := (SELECT l.SystemNo 
				FROM Location l JOIN Inventory i on l.SystemNo = i.SystemNo
				WHERE i.ISBN = bISBN and l.depNo = depNumber AND i.Taken = FALSE
				limit 10);
		INSERT INTO Borrows(ReaderID,SystemNo,BorrowDate,DueDate,ReturnDate)
		VALUES(rID,sysNo,currDate,returnDate,NULL);
		RETURN sysNo;
	END IF;
	RETURN NULL;
END
$$;

alter function borrow_book(integer, char, integer) owner to postgres;

