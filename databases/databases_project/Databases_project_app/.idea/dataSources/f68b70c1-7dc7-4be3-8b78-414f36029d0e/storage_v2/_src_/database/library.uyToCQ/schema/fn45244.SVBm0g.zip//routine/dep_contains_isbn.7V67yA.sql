create function dep_contains_isbn(bisbn character, depnumber integer) returns boolean
    language plpgsql
as
$$
BEGIN
	IF NOT EXISTS (SELECT 1 FROM Inventory WHERE ISBN = bISBN)
	THEN
		RAISE unique_violation USING MESSAGE = 'No book with that isbn in inventory';
		RETURN FALSE;
	END IF;
	
	IF NOT EXISTS (SELECT 1 FROM Department WHERE depNo = depNumber)
	THEN
		RAISE unique_violation USING MESSAGE = 'No such department exists';
		RETURN FALSE;
	END IF;
	
	RETURN EXISTS (SELECT 1 
				FROM Location l JOIN Inventory i on l.SystemNo = i.SystemNo 
				WHERE i.ISBN = bISBN and l.depNo = depNumber AND i.Taken = FALSE);
END
$$;

alter function dep_contains_isbn(char, integer) owner to postgres;

