create function register_person(pno character, rid integer) returns boolean
    language plpgsql
as
$$
DECLARE
	currDate DATE;
	yearAway DATE;
BEGIN
	currDate := CURRENT_DATE;
	yearAway := currDate + interval '1 year';
	
	IF EXISTS (SELECT 1 FROM Reader WHERE ReaderID = rID)
	THEN 	
		RAISE unique_violation USING MESSAGE = 'Reader already exists';
		RETURN FALSE;
	END IF;
	
	IF NOT EXISTS (SELECT 1 FROM Person WHERE PersonalNo = pNo)
	THEN 
		RAISE unique_violation USING MESSAGE = 'Person doesnt exist';
		RETURN FALSE;
	END IF;
	
	INSERT INTO Reader(ReaderID,RegistrationDate,ExpirationDate)
	VALUES(rID,currDate,yearAway);
	INSERT INTO Registered(PersonalNo,ReaderID)
	VALUES (pNo,rID);
	RETURN TRUE;
END
$$;

alter function register_person(char, integer) owner to postgres;

