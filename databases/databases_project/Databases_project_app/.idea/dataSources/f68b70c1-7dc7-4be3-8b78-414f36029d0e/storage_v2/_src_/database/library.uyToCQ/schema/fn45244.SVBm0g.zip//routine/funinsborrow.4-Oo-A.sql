create function funinsborrow() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (TG_OP = 'INSERT') THEN
	UPDATE Inventory
	SET Taken = TRUE
	WHERE SystemNo = OLD.SystemNo;
	END IF;
	RETURN NEW;
END
$$;

alter function funinsborrow() owner to postgres;

