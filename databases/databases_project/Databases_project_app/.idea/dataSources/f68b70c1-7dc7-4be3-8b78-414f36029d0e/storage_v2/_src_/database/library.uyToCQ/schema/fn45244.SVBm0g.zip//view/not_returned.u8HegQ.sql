create view not_returned(reader, bookno, returndate) as
SELECT r.readerid AS reader,
       b.systemno AS bookno,
       b.duedate  AS returndate
FROM ((fn45244.reader r
    JOIN fn45244.borrows b ON ((b.readerid = r.readerid)))
         JOIN (SELECT inventory.systemno,
                      inventory.isbn,
                      inventory.taken
               FROM fn45244.inventory
               WHERE (inventory.taken = true)) i ON (((i.systemno)::text = (b.systemno)::text)));

alter table not_returned
    owner to postgres;

