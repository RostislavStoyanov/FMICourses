create function most_read() returns character
    language sql
as
$$
(SELECT ISBN
	FROM Book
	WHERE ISBN =
			(SELECT ISBN
			FROM Inventory i
			JOIN Borrows b ON i.SystemNo = b.SystemNo
			GROUP BY ISBN
			HAVING COUNT(i.SystemNo) >= ALL
				(SELECT COUNT(i1.SystemNo)
		FROM Inventory i1
		JOIN Borrows b1 ON i1.SystemNo = b1.SystemNo
		GROUP BY ISBN)));
$$;

alter function most_read() owner to postgres;

